![memory map diagram](tests.test_docs_two_maps_cropped.png)
|name|origin|size|free Space|collisions
|:-|:-|:-|:-|:-|
|<span style='color:limegreen'>Blob2</span>|0x10|0x10|0x30|{}|
|<span style='color:palegreen'>Blob3</span>|0x50|0x10|0x388|{}|
|<span style='color:midnightblue'>Blob1</span>|0x10|0x10|0x3c8|{}|
