![memory map diagram](tests.test_docs_normal_cropped.png)
|name|origin|size|free Space|collisions
|:-|:-|:-|:-|:-|
|<span style='color:darkolivegreen'>kernel</span>|0x10|0x30|0x10|{}|
|<span style='color:maroon'>rootfs</span>|0x50|0x30|0x110|{}|
|<span style='color:darkslategray'>dtb</span>|0x190|0x30|0x228|{}|
