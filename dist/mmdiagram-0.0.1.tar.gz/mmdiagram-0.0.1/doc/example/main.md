|description|options|diagram|summary|
|:-:|:-:|:-:|:-:|
|No overlapping memory regions|<b>max height:</b> 1000 (0x3e8) bytes,<br><b>void threshold:</b> 200 (0xC8) bytes|![](tests.test_docs_normal_cropped.png)|![](tests.test_docs_normal_table.png)|
|Overlapping memory regions|<b>max height:</b> 1000 (0x3e8) bytes,<br><b>void threshold:</b> 200 (0xC8) bytes|![](tests.test_docs_collisions_cropped.png)|![](tests.test_docs_collisions_table.png)|
